const nodemailer = require('nodemailer');

let transporter = null;

const initTransporter = () => {
  if (process.env.EMAIL_USER && process.env.EMAIL_PASS) {
    transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST || 'smtp.gmail.com',
      port: parseInt(process.env.EMAIL_PORT) || 587,
      secure: false,
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    });
    console.log('📧 Email service configured');
  } else {
    console.log('📧 Email service not configured (EMAIL_USER/EMAIL_PASS not set) — skipping email notifications');
  }
};

const sendRenewalEmail = async (userEmail, userName, subscription) => {
  if (!transporter) return;

  const renewalDate = new Date(subscription.renewalDate).toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const mailOptions = {
    from: `"SOCA" <${process.env.EMAIL_USER}>`,
    to: userEmail,
    subject: `🔔 Renewal Reminder: ${subscription.serviceName}`,
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f0f2f5; margin: 0; padding: 20px; }
          .container { max-width: 520px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.08); }
          .header { background: linear-gradient(135deg, #6366f1, #8b5cf6); padding: 32px 24px; text-align: center; }
          .header h1 { color: #fff; margin: 0; font-size: 24px; }
          .header p { color: rgba(255,255,255,0.85); margin: 8px 0 0; }
          .body { padding: 32px 24px; }
          .info-card { background: #f8f9ff; border-radius: 12px; padding: 20px; margin: 16px 0; border-left: 4px solid #6366f1; }
          .info-row { display: flex; justify-content: space-between; margin: 8px 0; }
          .label { color: #64748b; font-size: 14px; }
          .value { color: #1e293b; font-weight: 600; font-size: 14px; }
          .cost { font-size: 28px; color: #6366f1; font-weight: 700; text-align: center; margin: 16px 0; }
          .footer { text-align: center; padding: 16px 24px 24px; color: #94a3b8; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🔔 Renewal Reminder</h1>
            <p>Subscription Optimization & Cost Analyzer</p>
          </div>
          <div class="body">
            <p>Hi <strong>${userName}</strong>,</p>
            <p>Your subscription is renewing soon:</p>
            <div class="info-card">
              <div class="info-row"><span class="label">Service</span><span class="value">${subscription.serviceName}</span></div>
              <div class="info-row"><span class="label">Category</span><span class="value">${subscription.category}</span></div>
              <div class="info-row"><span class="label">Renewal Date</span><span class="value">${renewalDate}</span></div>
              <div class="info-row"><span class="label">Billing Cycle</span><span class="value">${subscription.billingCycle}</span></div>
            </div>
            <div class="cost">$${subscription.cost.toFixed(2)}</div>
            <p style="text-align: center; color: #64748b;">Log into SOCA to manage your subscriptions.</p>
          </div>
          <div class="footer">
            <p>SOCA — Subscription Optimization & Cost Analyzer</p>
          </div>
        </div>
      </body>
      </html>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`📧 Renewal email sent to ${userEmail} for ${subscription.serviceName}`);
  } catch (error) {
    console.error(`❌ Email error: ${error.message}`);
  }
};

module.exports = { initTransporter, sendRenewalEmail };

import { useState, useEffect } from 'react';
import api from '../../services/api';
import SubscriptionCard from './SubscriptionCard';
import SubscriptionForm from './SubscriptionForm';
import Modal from '../common/Modal';
import LoadingSpinner from '../common/LoadingSpinner';
import { CATEGORIES } from '../../utils/constants';
import { formatCurrency } from '../../utils/formatters';
import './SubscriptionList.css';

const SubscriptionList = () => {
  const [subscriptions, setSubscriptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingSub, setEditingSub] = useState(null);
  const [filterStatus, setFilterStatus] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [sortBy, setSortBy] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchSubscriptions();
  }, [filterStatus, filterCategory, sortBy]);

  const fetchSubscriptions = async () => {
    try {
      const params = new URLSearchParams();
      if (filterStatus) params.append('status', filterStatus);
      if (filterCategory) params.append('category', filterCategory);
      if (sortBy) params.append('sort', sortBy);

      const res = await api.get(`/subscriptions?${params.toString()}`);
      setSubscriptions(res.data.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async (data) => {
    await api.post('/subscriptions', data);
    setShowForm(false);
    fetchSubscriptions();
  };

  const handleUpdate = async (data) => {
    await api.put(`/subscriptions/${editingSub._id}`, data);
    setEditingSub(null);
    fetchSubscriptions();
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this subscription?')) {
      await api.delete(`/subscriptions/${id}`);
      fetchSubscriptions();
    }
  };

  const filteredSubscriptions = subscriptions.filter(sub =>
    sub.serviceName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalMonthly = filteredSubscriptions
    .filter(s => s.status === 'active')
    .reduce((sum, sub) => {
      switch (sub.billingCycle) {
        case 'weekly': return sum + sub.cost * 4.33;
        case 'monthly': return sum + sub.cost;
        case 'quarterly': return sum + sub.cost / 3;
        case 'yearly': return sum + sub.cost / 12;
        default: return sum + sub.cost;
      }
    }, 0);

  if (loading) return <LoadingSpinner text="Loading subscriptions..." />;

  return (
    <div className="subscriptions-page" id="subscriptions-page">
      <div className="page-header">
        <div>
          <h1 className="page-title">Subscriptions</h1>
          <p className="page-subtitle">{subscriptions.length} subscriptions • {formatCurrency(totalMonthly)}/mo active</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowForm(true)} id="add-subscription-btn">
          + Add Subscription
        </button>
      </div>

      {/* Filters */}
      <div className="filters-bar glass-card animate-fade-in">
        <div className="filter-search">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input
            type="text"
            className="filter-search-input"
            placeholder="Search subscriptions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            id="search-subscriptions"
          />
        </div>

        <div className="filter-group">
          <select className="form-select filter-select" value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} id="filter-status">
            <option value="">All Status</option>
            <option value="active">Active</option>
            <option value="paused">Paused</option>
            <option value="cancelled">Cancelled</option>
          </select>

          <select className="form-select filter-select" value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)} id="filter-category">
            <option value="">All Categories</option>
            {CATEGORIES.map(cat => (
              <option key={cat.value} value={cat.value}>{cat.icon} {cat.label}</option>
            ))}
          </select>

          <select className="form-select filter-select" value={sortBy} onChange={(e) => setSortBy(e.target.value)} id="sort-by">
            <option value="">Sort: Newest</option>
            <option value="cost">Sort: Cost</option>
            <option value="renewal">Sort: Renewal Date</option>
            <option value="name">Sort: Name</option>
          </select>
        </div>
      </div>

      {/* Subscription Grid */}
      {filteredSubscriptions.length > 0 ? (
        <div className="sub-grid">
          {filteredSubscriptions.map((sub, idx) => (
            <div key={sub._id} className={`animate-fade-in-up stagger-${Math.min(idx + 1, 5)}`}>
              <SubscriptionCard
                subscription={sub}
                onEdit={setEditingSub}
                onDelete={handleDelete}
              />
            </div>
          ))}
        </div>
      ) : (
        <div className="glass-card empty-state animate-fade-in">
          <div className="empty-state-icon">📋</div>
          <h3>No Subscriptions Found</h3>
          <p>Add your first subscription to start tracking your spending.</p>
          <button className="btn btn-primary" onClick={() => setShowForm(true)}>
            + Add Subscription
          </button>
        </div>
      )}

      {/* Add Modal */}
      <Modal isOpen={showForm} onClose={() => setShowForm(false)} title="Add Subscription">
        <SubscriptionForm onSubmit={handleCreate} onCancel={() => setShowForm(false)} />
      </Modal>

      {/* Edit Modal */}
      <Modal isOpen={!!editingSub} onClose={() => setEditingSub(null)} title="Edit Subscription">
        <SubscriptionForm subscription={editingSub} onSubmit={handleUpdate} onCancel={() => setEditingSub(null)} />
      </Modal>
    </div>
  );
};

export default SubscriptionList;

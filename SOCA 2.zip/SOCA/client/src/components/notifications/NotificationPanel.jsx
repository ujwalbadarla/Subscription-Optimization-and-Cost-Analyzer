import { useState, useEffect } from 'react';
import api from '../../services/api';
import LoadingSpinner from '../common/LoadingSpinner';
import { formatDate } from '../../utils/formatters';
import './NotificationPanel.css';

const NotificationPanel = () => {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    try {
      const res = await api.get('/notifications');
      setNotifications(res.data.data);
      setUnreadCount(res.data.unreadCount);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (id) => {
    try {
      await api.put(`/notifications/${id}/read`);
      setNotifications(prev =>
        prev.map(n => n._id === id ? { ...n, read: true } : n)
      );
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (err) {
      console.error(err);
    }
  };

  const markAllAsRead = async () => {
    try {
      await api.put('/notifications/read-all');
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      setUnreadCount(0);
    } catch (err) {
      console.error(err);
    }
  };

  const deleteNotification = async (id) => {
    try {
      await api.delete(`/notifications/${id}`);
      setNotifications(prev => prev.filter(n => n._id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  const typeIcons = { renewal: '🔔', budget: '💰', recommendation: '💡', system: '⚙️' };
  const typeColors = { renewal: 'var(--warning-500)', budget: 'var(--danger-500)', recommendation: 'var(--primary-500)', system: 'var(--text-tertiary)' };

  if (loading) return <LoadingSpinner text="Loading notifications..." />;

  return (
    <div className="notifications-page" id="notifications-page">
      <div className="page-header">
        <div>
          <h1 className="page-title">Notifications</h1>
          <p className="page-subtitle">{unreadCount} unread notification{unreadCount !== 1 ? 's' : ''}</p>
        </div>
        {unreadCount > 0 && (
          <button className="btn btn-secondary" onClick={markAllAsRead} id="mark-all-read">
            ✓ Mark All Read
          </button>
        )}
      </div>

      <div className="notifications-list">
        {notifications.length > 0 ? (
          notifications.map((notification, idx) => (
            <div
              key={notification._id}
              className={`notification-item glass-card ${!notification.read ? 'unread' : ''} animate-fade-in-up stagger-${Math.min(idx + 1, 5)}`}
            >
              <div className="notification-icon" style={{ color: typeColors[notification.type] }}>
                {typeIcons[notification.type] || '🔔'}
              </div>
              <div className="notification-content">
                <p className="notification-message">{notification.message}</p>
                <div className="notification-meta">
                  <span className="notification-time">{formatDate(notification.createdAt)}</span>
                  {notification.subscriptionId && (
                    <span className="notification-service">
                      {notification.subscriptionId.serviceName || ''}
                    </span>
                  )}
                  <span className={`notification-type-badge ${notification.type}`}>
                    {notification.type}
                  </span>
                </div>
              </div>
              <div className="notification-actions">
                {!notification.read && (
                  <button
                    className="btn btn-ghost btn-sm"
                    onClick={() => markAsRead(notification._id)}
                    title="Mark as read"
                  >
                    ✓
                  </button>
                )}
                <button
                  className="btn btn-ghost btn-sm"
                  onClick={() => deleteNotification(notification._id)}
                  title="Delete"
                  style={{ color: 'var(--text-tertiary)' }}
                >
                  ✕
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="glass-card empty-state animate-fade-in">
            <div className="empty-state-icon">🔔</div>
            <h3>No Notifications</h3>
            <p>You're all caught up! Notifications will appear here for upcoming renewals and recommendations.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default NotificationPanel;

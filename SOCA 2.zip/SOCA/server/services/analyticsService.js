const Subscription = require('../models/Subscription');

/**
 * Get comprehensive analytics for a user
 */
const getAnalytics = async (userId) => {
  const subscriptions = await Subscription.find({ userId, status: 'active' });

  // Total monthly spend
  let totalMonthly = 0;
  subscriptions.forEach(sub => {
    totalMonthly += sub.monthlyCost;
  });

  // Total yearly spend
  const totalYearly = totalMonthly * 12;

  // Category breakdown
  const categoryMap = {};
  subscriptions.forEach(sub => {
    if (!categoryMap[sub.category]) {
      categoryMap[sub.category] = { count: 0, monthlyTotal: 0 };
    }
    categoryMap[sub.category].count += 1;
    categoryMap[sub.category].monthlyTotal += sub.monthlyCost;
  });

  const categoryBreakdown = Object.entries(categoryMap).map(([category, data]) => ({
    category,
    count: data.count,
    monthlyTotal: Math.round(data.monthlyTotal * 100) / 100,
    percentage: Math.round((data.monthlyTotal / totalMonthly) * 10000) / 100
  })).sort((a, b) => b.monthlyTotal - a.monthlyTotal);

  // Monthly spending trend (last 12 months simulation based on start dates)
  const monthlyTrend = [];
  const now = new Date();
  for (let i = 11; i >= 0; i--) {
    const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const monthLabel = date.toLocaleString('default', { month: 'short', year: 'numeric' });

    let monthTotal = 0;
    subscriptions.forEach(sub => {
      const startDate = new Date(sub.startDate);
      if (startDate <= new Date(date.getFullYear(), date.getMonth() + 1, 0)) {
        monthTotal += sub.monthlyCost;
      }
    });

    monthlyTrend.push({
      month: monthLabel,
      total: Math.round(monthTotal * 100) / 100
    });
  }

  // Billing cycle distribution
  const cycleDistribution = {};
  subscriptions.forEach(sub => {
    cycleDistribution[sub.billingCycle] = (cycleDistribution[sub.billingCycle] || 0) + 1;
  });

  // Most expensive subscription
  const mostExpensive = subscriptions.length > 0
    ? subscriptions.reduce((max, sub) => sub.monthlyCost > max.monthlyCost ? sub : max)
    : null;

  return {
    totalMonthly: Math.round(totalMonthly * 100) / 100,
    totalYearly: Math.round(totalYearly * 100) / 100,
    activeCount: subscriptions.length,
    categoryBreakdown,
    monthlyTrend,
    cycleDistribution,
    mostExpensive: mostExpensive ? {
      serviceName: mostExpensive.serviceName,
      monthlyCost: Math.round(mostExpensive.monthlyCost * 100) / 100
    } : null,
    averagePerSubscription: subscriptions.length > 0
      ? Math.round((totalMonthly / subscriptions.length) * 100) / 100
      : 0
  };
};

/**
 * Generate smart cost recommendations
 */
const getRecommendations = async (userId) => {
  const subscriptions = await Subscription.find({ userId });
  const recommendations = [];

  const active = subscriptions.filter(s => s.status === 'active');

  // 1. Identify expensive subscriptions (> $50/month)
  active.forEach(sub => {
    if (sub.monthlyCost > 50) {
      recommendations.push({
        type: 'expensive',
        severity: 'warning',
        subscription: sub.serviceName,
        message: `${sub.serviceName} costs $${sub.monthlyCost.toFixed(2)}/month. Consider if you're using all features or if a cheaper plan exists.`,
        potentialSavings: Math.round(sub.monthlyCost * 0.3 * 100) / 100
      });
    }
  });

  // 2. Detect potential duplicates (same category)
  const categoryGroups = {};
  active.forEach(sub => {
    if (!categoryGroups[sub.category]) categoryGroups[sub.category] = [];
    categoryGroups[sub.category].push(sub);
  });

  Object.entries(categoryGroups).forEach(([category, subs]) => {
    if (subs.length >= 2) {
      const totalCost = subs.reduce((sum, s) => sum + s.monthlyCost, 0);
      recommendations.push({
        type: 'duplicate',
        severity: 'info',
        subscription: subs.map(s => s.serviceName).join(', '),
        message: `You have ${subs.length} subscriptions in the "${category}" category (${subs.map(s => s.serviceName).join(', ')}). Total: $${totalCost.toFixed(2)}/month. Consider consolidating.`,
        potentialSavings: Math.round(totalCost * 0.4 * 100) / 100
      });
    }
  });

  // 3. Suggest annual billing for monthly subscriptions
  active.filter(s => s.billingCycle === 'monthly' && s.cost > 10).forEach(sub => {
    recommendations.push({
      type: 'billing_switch',
      severity: 'tip',
      subscription: sub.serviceName,
      message: `Switch ${sub.serviceName} from monthly ($${sub.cost}) to annual billing. Most services offer 15-20% discounts for annual plans.`,
      potentialSavings: Math.round(sub.cost * 12 * 0.17 / 12 * 100) / 100
    });
  });

  // 4. Paused subscriptions that could be cancelled
  const paused = subscriptions.filter(s => s.status === 'paused');
  paused.forEach(sub => {
    recommendations.push({
      type: 'unused',
      severity: 'warning',
      subscription: sub.serviceName,
      message: `${sub.serviceName} has been paused. If you haven't used it recently, consider cancelling to save $${sub.monthlyCost.toFixed(2)}/month.`,
      potentialSavings: Math.round(sub.monthlyCost * 100) / 100
    });
  });

  // Calculate total potential savings
  const totalPotentialSavings = recommendations.reduce((sum, r) => sum + (r.potentialSavings || 0), 0);

  return {
    recommendations,
    totalPotentialSavings: Math.round(totalPotentialSavings * 100) / 100,
    count: recommendations.length
  };
};

module.exports = { getAnalytics, getRecommendations };

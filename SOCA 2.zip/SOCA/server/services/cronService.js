const cron = require('node-cron');
const Subscription = require('../models/Subscription');
const Notification = require('../models/Notification');
const User = require('../models/User');
const { sendRenewalEmail } = require('./emailService');

const startCronJobs = () => {
  // Run daily at midnight — check for upcoming renewals
  cron.schedule('0 0 * * *', async () => {
    console.log('⏰ Running daily renewal check...');
    try {
      const now = new Date();
      const threeDaysFromNow = new Date();
      threeDaysFromNow.setDate(threeDaysFromNow.getDate() + 3);

      // Find subscriptions renewing in the next 3 days
      const upcomingRenewals = await Subscription.find({
        status: 'active',
        renewalDate: { $gte: now, $lte: threeDaysFromNow }
      });

      console.log(`Found ${upcomingRenewals.length} upcoming renewals`);

      for (const sub of upcomingRenewals) {
        // Check if notification already sent for this renewal
        const existingNotification = await Notification.findOne({
          subscriptionId: sub._id,
          type: 'renewal',
          createdAt: { $gte: new Date(now.setHours(0, 0, 0, 0)) }
        });

        if (!existingNotification) {
          const daysUntilRenewal = Math.ceil((sub.renewalDate - new Date()) / (1000 * 60 * 60 * 24));

          // Create in-app notification
          await Notification.create({
            userId: sub.userId,
            subscriptionId: sub._id,
            message: `${sub.serviceName} renews in ${daysUntilRenewal} day${daysUntilRenewal !== 1 ? 's' : ''} — $${sub.cost.toFixed(2)} (${sub.billingCycle})`,
            type: 'renewal'
          });

          // Send email notification
          const user = await User.findById(sub.userId);
          if (user) {
            await sendRenewalEmail(user.email, user.name, sub);
          }
        }
      }

      // Auto-advance renewal dates for past-due active subscriptions
      const pastDue = await Subscription.find({
        status: 'active',
        renewalDate: { $lt: now }
      });

      for (const sub of pastDue) {
        const newRenewalDate = new Date(sub.renewalDate);
        switch (sub.billingCycle) {
          case 'weekly':
            newRenewalDate.setDate(newRenewalDate.getDate() + 7);
            break;
          case 'monthly':
            newRenewalDate.setMonth(newRenewalDate.getMonth() + 1);
            break;
          case 'quarterly':
            newRenewalDate.setMonth(newRenewalDate.getMonth() + 3);
            break;
          case 'yearly':
            newRenewalDate.setFullYear(newRenewalDate.getFullYear() + 1);
            break;
        }
        sub.renewalDate = newRenewalDate;
        await sub.save();
      }

      console.log('✅ Daily renewal check complete');
    } catch (error) {
      console.error('❌ Cron job error:', error.message);
    }
  });

  console.log('⏰ Cron jobs scheduled (daily at midnight)');
};

module.exports = { startCronJobs };

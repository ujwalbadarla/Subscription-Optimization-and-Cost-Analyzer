import { useState } from 'react';
import { CATEGORIES, BILLING_CYCLES, STATUSES } from '../../utils/constants';
import './SubscriptionForm.css';

const SubscriptionForm = ({ subscription, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    serviceName: subscription?.serviceName || '',
    category: subscription?.category || 'other',
    cost: subscription?.cost || '',
    billingCycle: subscription?.billingCycle || 'monthly',
    startDate: subscription?.startDate ? new Date(subscription.startDate).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
    renewalDate: subscription?.renewalDate ? new Date(subscription.renewalDate).toISOString().split('T')[0] : '',
    status: subscription?.status || 'active',
    notes: subscription?.notes || ''
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onSubmit({
        ...formData,
        cost: parseFloat(formData.cost)
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const isEditing = !!subscription;

  return (
    <form onSubmit={handleSubmit} className="sub-form" id="subscription-form">
      <div className="sub-form-grid">
        <div className="form-group">
          <label className="form-label" htmlFor="serviceName">Service Name *</label>
          <input
            id="serviceName"
            name="serviceName"
            type="text"
            className="form-input"
            placeholder="e.g., Netflix, Spotify"
            value={formData.serviceName}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="category">Category *</label>
          <select id="category" name="category" className="form-select" value={formData.category} onChange={handleChange}>
            {CATEGORIES.map(cat => (
              <option key={cat.value} value={cat.value}>{cat.icon} {cat.label}</option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="cost">Cost ($) *</label>
          <input
            id="cost"
            name="cost"
            type="number"
            step="0.01"
            min="0"
            className="form-input"
            placeholder="9.99"
            value={formData.cost}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="billingCycle">Billing Cycle *</label>
          <select id="billingCycle" name="billingCycle" className="form-select" value={formData.billingCycle} onChange={handleChange}>
            {BILLING_CYCLES.map(cycle => (
              <option key={cycle.value} value={cycle.value}>{cycle.label}</option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="startDate">Start Date *</label>
          <input
            id="startDate"
            name="startDate"
            type="date"
            className="form-input"
            value={formData.startDate}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="renewalDate">Next Renewal Date</label>
          <input
            id="renewalDate"
            name="renewalDate"
            type="date"
            className="form-input"
            value={formData.renewalDate}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="status">Status</label>
          <select id="status" name="status" className="form-select" value={formData.status} onChange={handleChange}>
            {STATUSES.map(s => (
              <option key={s.value} value={s.value}>{s.label}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="form-group" style={{ marginTop: 'var(--space-4)' }}>
        <label className="form-label" htmlFor="notes">Notes (optional)</label>
        <textarea
          id="notes"
          name="notes"
          className="form-input"
          rows="3"
          placeholder="Any additional notes..."
          value={formData.notes}
          onChange={handleChange}
          style={{ resize: 'vertical' }}
        />
      </div>

      <div className="sub-form-actions">
        <button type="button" className="btn btn-secondary" onClick={onCancel}>Cancel</button>
        <button type="submit" className="btn btn-primary" disabled={loading} id="subscription-submit">
          {loading ? 'Saving...' : isEditing ? 'Update Subscription' : 'Add Subscription'}
        </button>
      </div>
    </form>
  );
};

export default SubscriptionForm;

const mongoose = require('mongoose');

const subscriptionSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  serviceName: {
    type: String,
    required: [true, 'Please provide a service name'],
    trim: true
  },
  category: {
    type: String,
    required: true,
    enum: ['streaming', 'software', 'cloud', 'music', 'gaming', 'fitness', 'news', 'food', 'education', 'productivity', 'other'],
    default: 'other'
  },
  cost: {
    type: Number,
    required: [true, 'Please provide the cost'],
    min: 0
  },
  billingCycle: {
    type: String,
    required: true,
    enum: ['weekly', 'monthly', 'quarterly', 'yearly'],
    default: 'monthly'
  },
  startDate: {
    type: Date,
    required: true,
    default: Date.now
  },
  renewalDate: {
    type: Date,
    required: true
  },
  status: {
    type: String,
    enum: ['active', 'paused', 'cancelled'],
    default: 'active'
  },
  notes: {
    type: String,
    maxlength: 500
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual: normalized monthly cost for comparison
subscriptionSchema.virtual('monthlyCost').get(function () {
  switch (this.billingCycle) {
    case 'weekly': return this.cost * 4.33;
    case 'monthly': return this.cost;
    case 'quarterly': return this.cost / 3;
    case 'yearly': return this.cost / 12;
    default: return this.cost;
  }
});

// Compound index for cron performance
subscriptionSchema.index({ userId: 1, renewalDate: 1 });
subscriptionSchema.index({ status: 1, renewalDate: 1 });

module.exports = mongoose.model('Subscription', subscriptionSchema);

const Subscription = require('../models/Subscription');
const { getAnalytics, getRecommendations } = require('../services/analyticsService');

// @desc    Get all subscriptions for user
// @route   GET /api/subscriptions
exports.getSubscriptions = async (req, res) => {
  try {
    const { status, category, sort } = req.query;
    const filter = { userId: req.user._id };

    if (status) filter.status = status;
    if (category) filter.category = category;

    let sortObj = { createdAt: -1 };
    if (sort === 'cost') sortObj = { cost: -1 };
    if (sort === 'renewal') sortObj = { renewalDate: 1 };
    if (sort === 'name') sortObj = { serviceName: 1 };

    const subscriptions = await Subscription.find(filter).sort(sortObj);

    res.json({ success: true, count: subscriptions.length, data: subscriptions });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get single subscription
// @route   GET /api/subscriptions/:id
exports.getSubscription = async (req, res) => {
  try {
    const subscription = await Subscription.findOne({ _id: req.params.id, userId: req.user._id });

    if (!subscription) {
      return res.status(404).json({ success: false, message: 'Subscription not found' });
    }

    res.json({ success: true, data: subscription });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Create subscription
// @route   POST /api/subscriptions
exports.createSubscription = async (req, res) => {
  try {
    req.body.userId = req.user._id;

    // Auto-calculate renewal date if not provided
    if (!req.body.renewalDate && req.body.startDate) {
      const start = new Date(req.body.startDate);
      switch (req.body.billingCycle) {
        case 'weekly':
          start.setDate(start.getDate() + 7);
          break;
        case 'monthly':
          start.setMonth(start.getMonth() + 1);
          break;
        case 'quarterly':
          start.setMonth(start.getMonth() + 3);
          break;
        case 'yearly':
          start.setFullYear(start.getFullYear() + 1);
          break;
      }
      req.body.renewalDate = start;
    }

    const subscription = await Subscription.create(req.body);

    res.status(201).json({ success: true, data: subscription });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Update subscription
// @route   PUT /api/subscriptions/:id
exports.updateSubscription = async (req, res) => {
  try {
    let subscription = await Subscription.findOne({ _id: req.params.id, userId: req.user._id });

    if (!subscription) {
      return res.status(404).json({ success: false, message: 'Subscription not found' });
    }

    subscription = await Subscription.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    res.json({ success: true, data: subscription });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Delete subscription
// @route   DELETE /api/subscriptions/:id
exports.deleteSubscription = async (req, res) => {
  try {
    const subscription = await Subscription.findOne({ _id: req.params.id, userId: req.user._id });

    if (!subscription) {
      return res.status(404).json({ success: false, message: 'Subscription not found' });
    }

    await subscription.deleteOne();

    res.json({ success: true, message: 'Subscription deleted' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get upcoming renewals (next 7 days)
// @route   GET /api/subscriptions/upcoming
exports.getUpcomingRenewals = async (req, res) => {
  try {
    const now = new Date();
    const nextWeek = new Date();
    nextWeek.setDate(nextWeek.getDate() + 7);

    const subscriptions = await Subscription.find({
      userId: req.user._id,
      status: 'active',
      renewalDate: { $gte: now, $lte: nextWeek }
    }).sort({ renewalDate: 1 });

    res.json({ success: true, count: subscriptions.length, data: subscriptions });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get analytics data
// @route   GET /api/subscriptions/analytics
exports.getAnalyticsData = async (req, res) => {
  try {
    const analytics = await getAnalytics(req.user._id);
    res.json({ success: true, data: analytics });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get smart recommendations
// @route   GET /api/subscriptions/recommendations
exports.getRecommendationsData = async (req, res) => {
  try {
    const recommendations = await getRecommendations(req.user._id);
    res.json({ success: true, data: recommendations });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const express = require('express');
const router = express.Router();
const {
  getSubscriptions,
  getSubscription,
  createSubscription,
  updateSubscription,
  deleteSubscription,
  getUpcomingRenewals,
  getAnalyticsData,
  getRecommendationsData
} = require('../controllers/subscriptionController');
const { protect } = require('../middleware/auth');

// All routes are protected
router.use(protect);

// Analytics routes (must be before /:id routes)
router.get('/analytics', getAnalyticsData);
router.get('/upcoming', getUpcomingRenewals);
router.get('/recommendations', getRecommendationsData);

// CRUD routes
router.route('/')
  .get(getSubscriptions)
  .post(createSubscription);

router.route('/:id')
  .get(getSubscription)
  .put(updateSubscription)
  .delete(deleteSubscription);

module.exports = router;

import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import api from '../../services/api';
import { formatCurrency, formatDate, getDaysUntil } from '../../utils/formatters';
import { getCategoryInfo } from '../../utils/constants';
import LoadingSpinner from '../common/LoadingSpinner';
import './Dashboard.css';

const StatCard = ({ icon, label, value, subtitle, gradient, delay }) => (
  <div className={`stat-card animate-fade-in-up stagger-${delay}`}>
    <div className="stat-card-icon" style={{ background: gradient }}>{icon}</div>
    <div className="stat-card-content">
      <p className="stat-card-label">{label}</p>
      <h3 className="stat-card-value">{value}</h3>
      {subtitle && <p className="stat-card-subtitle">{subtitle}</p>}
    </div>
  </div>
);

const Dashboard = () => {
  const [analytics, setAnalytics] = useState(null);
  const [upcoming, setUpcoming] = useState([]);
  const [subscriptions, setSubscriptions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [analyticsRes, upcomingRes, subsRes] = await Promise.all([
        api.get('/subscriptions/analytics'),
        api.get('/subscriptions/upcoming'),
        api.get('/subscriptions?sort=renewal&status=active')
      ]);
      setAnalytics(analyticsRes.data.data);
      setUpcoming(upcomingRes.data.data);
      setSubscriptions(subsRes.data.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <LoadingSpinner text="Loading dashboard..." />;

  return (
    <div className="dashboard" id="dashboard-page">
      <div className="page-header">
        <div>
          <h1 className="page-title">Dashboard</h1>
          <p className="page-subtitle">Your subscription overview at a glance</p>
        </div>
        <Link to="/subscriptions" className="btn btn-primary">
          + Add Subscription
        </Link>
      </div>

      {/* Stat Cards */}
      <div className="stats-grid">
        <StatCard
          icon="💰"
          label="Monthly Spend"
          value={formatCurrency(analytics?.totalMonthly || 0)}
          subtitle={`${formatCurrency(analytics?.totalYearly || 0)}/year`}
          gradient="linear-gradient(135deg, #6366f1, #8b5cf6)"
          delay={1}
        />
        <StatCard
          icon="📋"
          label="Active Subscriptions"
          value={analytics?.activeCount || 0}
          subtitle={`Avg ${formatCurrency(analytics?.averagePerSubscription || 0)}/each`}
          gradient="linear-gradient(135deg, #14b8a6, #06b6d4)"
          delay={2}
        />
        <StatCard
          icon="🔔"
          label="Upcoming Renewals"
          value={upcoming.length}
          subtitle="Next 7 days"
          gradient="linear-gradient(135deg, #f59e0b, #f97316)"
          delay={3}
        />
        <StatCard
          icon="📊"
          label="Top Category"
          value={analytics?.categoryBreakdown?.[0]?.category ? getCategoryInfo(analytics.categoryBreakdown[0].category).label : 'N/A'}
          subtitle={analytics?.categoryBreakdown?.[0] ? formatCurrency(analytics.categoryBreakdown[0].monthlyTotal) + '/mo' : ''}
          gradient="linear-gradient(135deg, #ec4899, #f43f5e)"
          delay={4}
        />
      </div>

      {/* Charts + Upcoming */}
      <div className="dashboard-grid">
        {/* Spending Trend */}
        <div className="glass-card dashboard-chart animate-fade-in-up stagger-5">
          <h2 className="card-title">Spending Trend</h2>
          <div className="chart-container">
            {analytics?.monthlyTrend?.length > 0 ? (
              <ResponsiveContainer width="100%" height={280}>
                <AreaChart data={analytics.monthlyTrend} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border-light)" />
                  <XAxis dataKey="month" tick={{ fontSize: 12, fill: 'var(--text-tertiary)' }} />
                  <YAxis tick={{ fontSize: 12, fill: 'var(--text-tertiary)' }} tickFormatter={(v) => `$${v}`} />
                  <Tooltip
                    contentStyle={{
                      background: 'var(--bg-card)',
                      border: '1px solid var(--border-light)',
                      borderRadius: '10px',
                      boxShadow: 'var(--shadow-lg)',
                      fontSize: '13px'
                    }}
                    formatter={(value) => [formatCurrency(value), 'Total']}
                  />
                  <Area type="monotone" dataKey="total" stroke="#6366f1" strokeWidth={2.5} fill="url(#colorTotal)" />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="empty-chart">
                <p>📊 Add subscriptions to see spending trends</p>
              </div>
            )}
          </div>
        </div>

        {/* Upcoming Renewals */}
        <div className="glass-card dashboard-upcoming animate-fade-in-up stagger-5">
          <h2 className="card-title">Upcoming Renewals</h2>
          <div className="upcoming-list">
            {upcoming.length > 0 ? (
              upcoming.map((sub) => {
                const days = getDaysUntil(sub.renewalDate);
                const catInfo = getCategoryInfo(sub.category);
                return (
                  <div key={sub._id} className="upcoming-item">
                    <div className="upcoming-icon">{catInfo.icon}</div>
                    <div className="upcoming-info">
                      <p className="upcoming-name">{sub.serviceName}</p>
                      <p className="upcoming-date">{formatDate(sub.renewalDate)}</p>
                    </div>
                    <div className="upcoming-right">
                      <p className="upcoming-cost">{formatCurrency(sub.cost)}</p>
                      <span className={`upcoming-days ${days <= 1 ? 'urgent' : days <= 3 ? 'soon' : ''}`}>
                        {days === 0 ? 'Today' : days === 1 ? 'Tomorrow' : `${days} days`}
                      </span>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="upcoming-empty">
                <p>✅ No renewals in the next 7 days</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Recent Subscriptions */}
      <div className="glass-card recent-subs animate-fade-in-up">
        <div className="card-header">
          <h2 className="card-title">Active Subscriptions</h2>
          <Link to="/subscriptions" className="btn btn-ghost btn-sm">View All →</Link>
        </div>
        <div className="recent-subs-list">
          {subscriptions.slice(0, 5).map((sub) => {
            const catInfo = getCategoryInfo(sub.category);
            return (
              <div key={sub._id} className="recent-sub-item">
                <div className="recent-sub-icon" style={{ background: `${catInfo.color}18`, color: catInfo.color }}>
                  {catInfo.icon}
                </div>
                <div className="recent-sub-info">
                  <p className="recent-sub-name">{sub.serviceName}</p>
                  <p className="recent-sub-category">{catInfo.label} • {sub.billingCycle}</p>
                </div>
                <div className="recent-sub-cost">
                  <p className="recent-sub-amount">{formatCurrency(sub.cost)}</p>
                  <p className="recent-sub-cycle">/{sub.billingCycle === 'yearly' ? 'yr' : sub.billingCycle === 'quarterly' ? 'qtr' : sub.billingCycle === 'weekly' ? 'wk' : 'mo'}</p>
                </div>
              </div>
            );
          })}
          {subscriptions.length === 0 && (
            <div className="upcoming-empty">
              <p>📋 No active subscriptions yet. <Link to="/subscriptions">Add one!</Link></p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

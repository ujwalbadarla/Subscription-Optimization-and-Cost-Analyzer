import { formatCurrency, formatDate, getDaysUntil } from '../../utils/formatters';
import { getCategoryInfo } from '../../utils/constants';
import './SubscriptionCard.css';

const SubscriptionCard = ({ subscription, onEdit, onDelete }) => {
  const catInfo = getCategoryInfo(subscription.category);
  const daysUntilRenewal = getDaysUntil(subscription.renewalDate);
  const monthlyCost = (() => {
    switch (subscription.billingCycle) {
      case 'weekly': return subscription.cost * 4.33;
      case 'monthly': return subscription.cost;
      case 'quarterly': return subscription.cost / 3;
      case 'yearly': return subscription.cost / 12;
      default: return subscription.cost;
    }
  })();

  return (
    <div className="sub-card glass-card">
      <div className="sub-card-header">
        <div className="sub-card-icon" style={{ background: `${catInfo.color}15`, color: catInfo.color }}>
          {catInfo.icon}
        </div>
        <div className="sub-card-title-group">
          <h3 className="sub-card-name">{subscription.serviceName}</h3>
          <span className="sub-card-category">{catInfo.label}</span>
        </div>
        <span className={`badge badge-${subscription.status}`}>{subscription.status}</span>
      </div>

      <div className="sub-card-body">
        <div className="sub-card-cost">
          <span className="sub-card-amount">{formatCurrency(subscription.cost)}</span>
          <span className="sub-card-cycle">/{subscription.billingCycle === 'yearly' ? 'yr' : subscription.billingCycle === 'quarterly' ? 'qtr' : subscription.billingCycle === 'weekly' ? 'wk' : 'mo'}</span>
        </div>
        <p className="sub-card-monthly">{formatCurrency(monthlyCost)}/mo equivalent</p>

        <div className="sub-card-details">
          <div className="sub-card-detail">
            <span className="sub-card-detail-label">Start Date</span>
            <span className="sub-card-detail-value">{formatDate(subscription.startDate)}</span>
          </div>
          <div className="sub-card-detail">
            <span className="sub-card-detail-label">Next Renewal</span>
            <span className={`sub-card-detail-value ${daysUntilRenewal <= 3 && daysUntilRenewal >= 0 ? 'text-warning' : ''}`}>
              {formatDate(subscription.renewalDate)}
              {daysUntilRenewal >= 0 && daysUntilRenewal <= 7 && (
                <span className="renewal-badge">{daysUntilRenewal === 0 ? 'Today!' : `${daysUntilRenewal}d`}</span>
              )}
            </span>
          </div>
        </div>
      </div>

      <div className="sub-card-actions">
        <button className="btn btn-ghost btn-sm" onClick={() => onEdit(subscription)} id={`edit-sub-${subscription._id}`}>
          ✏️ Edit
        </button>
        <button className="btn btn-ghost btn-sm" style={{ color: 'var(--danger-500)' }} onClick={() => onDelete(subscription._id)} id={`delete-sub-${subscription._id}`}>
          🗑️ Delete
        </button>
      </div>
    </div>
  );
};

export default SubscriptionCard;

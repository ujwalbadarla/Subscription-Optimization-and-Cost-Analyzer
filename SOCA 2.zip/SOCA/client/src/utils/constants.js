export const CATEGORIES = [
  { value: 'streaming', label: 'Streaming', icon: '📺', color: '#ef4444' },
  { value: 'software', label: 'Software', icon: '💻', color: '#6366f1' },
  { value: 'cloud', label: 'Cloud', icon: '☁️', color: '#06b6d4' },
  { value: 'music', label: 'Music', icon: '🎵', color: '#8b5cf6' },
  { value: 'gaming', label: 'Gaming', icon: '🎮', color: '#22c55e' },
  { value: 'fitness', label: 'Fitness', icon: '💪', color: '#f97316' },
  { value: 'news', label: 'News', icon: '📰', color: '#64748b' },
  { value: 'food', label: 'Food', icon: '🍕', color: '#eab308' },
  { value: 'education', label: 'Education', icon: '📚', color: '#14b8a6' },
  { value: 'productivity', label: 'Productivity', icon: '⚡', color: '#f43f5e' },
  { value: 'other', label: 'Other', icon: '📦', color: '#94a3b8' }
];

export const BILLING_CYCLES = [
  { value: 'weekly', label: 'Weekly' },
  { value: 'monthly', label: 'Monthly' },
  { value: 'quarterly', label: 'Quarterly' },
  { value: 'yearly', label: 'Yearly' }
];

export const STATUSES = [
  { value: 'active', label: 'Active' },
  { value: 'paused', label: 'Paused' },
  { value: 'cancelled', label: 'Cancelled' }
];

export const CHART_COLORS = [
  '#6366f1', '#8b5cf6', '#06b6d4', '#14b8a6', '#22c55e',
  '#f59e0b', '#ef4444', '#f97316', '#ec4899', '#64748b', '#eab308'
];

export const getCategoryInfo = (value) => {
  return CATEGORIES.find(c => c.value === value) || CATEGORIES[CATEGORIES.length - 1];
};

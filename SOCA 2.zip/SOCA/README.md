# SOCA — Subscription Optimization & Cost Analyzer

A full-stack MERN application to track, analyze, and optimize your subscription spending with smart insights, renewal alerts, and cost reduction recommendations.

## Features

- **Dashboard** — Overview of total spending, active subscriptions, upcoming renewals
- **Subscription Management** — Add, edit, delete subscriptions with search & filters
- **Analytics** — Interactive charts (spending trends, category breakdown, comparisons)
- **Smart Recommendations** — Detect duplicates, suggest annual billing, identify expensive subs
- **Notifications** — In-app alerts for upcoming renewals
- **Email Reminders** — Automated daily cron job sends renewal reminder emails
- **Dark Mode** — Toggle between light and dark themes
- **Export Reports** — Download PDF and Excel reports
- **JWT Authentication** — Secure login/register with bcrypt password hashing

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Vite, Recharts |
| Backend | Node.js, Express.js |
| Database | MongoDB, Mongoose |
| Auth | JWT, bcryptjs |
| Cron | node-cron |
| Email | Nodemailer |
| Export | jsPDF, xlsx |

## Quick Start

### Prerequisites
- Node.js 18+
- MongoDB (local or Atlas)

### 1. Clone & Setup
```bash
cd SOCA
```

### 2. Install Dependencies
```bash
# Backend
cd server
npm install
http://localhost:5000

# Frontend
cd ../client
npm install
```

### 3. Configure Environment
Edit `server/.env`:
```
MONGO_URI=mongodb://localhost:27017/soca
JWT_SECRET=your_secure_secret
```

### 4. Start the App
```bash
# Terminal 1 — Backend
cd server
npm run dev

# Terminal 2 — Frontend
cd client
npm run dev
```

- Frontend: http://localhost:3000
- Backend API: http://localhost:5000

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/register | Register user |
| POST | /api/auth/login | Login user |
| GET | /api/auth/me | Get current user |
| GET | /api/subscriptions | List subscriptions |
| POST | /api/subscriptions | Create subscription |
| PUT | /api/subscriptions/:id | Update subscription |
| DELETE | /api/subscriptions/:id | Delete subscription |
| GET | /api/subscriptions/analytics | Get analytics data |
| GET | /api/subscriptions/upcoming | Upcoming renewals |
| GET | /api/subscriptions/recommendations | Smart recommendations |
| GET | /api/notifications | List notifications |
| PUT | /api/notifications/:id/read | Mark as read |
| PUT | /api/notifications/read-all | Mark all read |
| DELETE | /api/notifications/:id | Delete notification |
